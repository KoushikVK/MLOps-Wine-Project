from setuptools import setup,find_packages  


setup(

  name = "src",version='1.0',description ="its an MLOPS Project",
  author ="koushik", author_email='koushikofficial@yahoo.com',
  packages = find_packages(),license="MIT"
)